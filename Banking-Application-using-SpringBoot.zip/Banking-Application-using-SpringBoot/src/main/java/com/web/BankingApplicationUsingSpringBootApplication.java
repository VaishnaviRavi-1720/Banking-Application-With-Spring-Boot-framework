package com.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingApplicationUsingSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingApplicationUsingSpringBootApplication.class, args);
	}

}
